import random
import pygame
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk

# Inicia Pygame (som e partículas)
pygame.init()
pygame.mixer.init()

# Sons (substitua por seus arquivos .wav, ou comente se não tiver)
try:
    sound_win = pygame.mixer.Sound("win_sound.wav")
    sound_loss = pygame.mixer.Sound("loss_sound.wav")
except:
    sound_win = None
    sound_loss = None

# Janela Pygame para efeitos visuais
WIDTH, HEIGHT = 600, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Efeitos Jackpot")

particles = []

def generate_particles(x, y):
    for _ in range(50):
        particles.append({
            'x': x,
            'y': y,
            'vx': random.uniform(-2, 2),
            'vy': random.uniform(-2, 2),
            'size': random.randint(3, 7),
            'color': (random.randint(150, 255), random.randint(150, 255), random.randint(0, 255))
        })

def update_particles():
    for p in particles[:]:
        p['x'] += p['vx']
        p['y'] += p['vy']
        p['size'] -= 0.1
        if p['size'] <= 0:
            particles.remove(p)

def draw_particles():
    screen.fill((0, 0, 0))
    for p in particles:
        pygame.draw.circle(screen, p['color'], (int(p['x']), int(p['y'])), int(p['size']))
    pygame.display.flip()

# Funções principais do Jackpot
def spin(force_symbol=None):
    symbols = ['♠️', '♣️', '♥️', '♦️']
    return [force_symbol] * 3 if force_symbol else [random.choice(symbols) for _ in range(3)]

def is_jackpot(result):
    return result.count(result[0]) == len(result)

# Tkinter Game
class JackpotApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Jackpot Slot Machine")
        self.geometry("400x500")
        self.configure(bg="black")

        self.credits = 5
        self.secret_code = "hackthejackpot"
        self.history = []
        self.total_points = 0

        self.create_widgets()

        self.update_particles_loop()

    def create_widgets(self):
        self.credit_label = tk.Label(self, text=f"Créditos: {self.credits}", font=("Arial", 16), fg="white", bg="black")
        self.credit_label.pack(pady=10)

        self.points_label = tk.Label(self, text=f"Pontuação: {self.total_points}", font=("Arial", 16), fg="white", bg="black")
        self.points_label.pack(pady=10)

        self.result_label = tk.Label(self, text="🃏 | 🃏 | 🃏", font=("Arial", 24), fg="yellow", bg="black")
        self.result_label.pack(pady=20)

        self.history_list = tk.Listbox(self, width=40, height=6, font=("Arial", 10), bg="lightgrey")
        self.history_list.pack(pady=10)

        self.secret_entry = tk.Entry(self, font=("Arial", 14))
        self.secret_entry.pack(pady=10)

        self.spin_button = tk.Button(self, text="GIRAR", font=("Arial", 14), fg="white", bg="blue", command=self.spin_slots)
        self.spin_button.pack(pady=15)

        self.progress = ttk.Progressbar(self, length=200, maximum=10, value=self.credits)
        self.progress.pack(pady=10)

    def spin_slots(self):
        if self.credits <= 0:
            self.end_game()
            return

        self.credits -= 1
        self.update_display()

        force = self.secret_entry.get().strip() == self.secret_code
        result = spin(result[0] if force else None)
        self.result_label.config(text=f"{result[0]} | {result[1]} | {result[2]}")

        self.history.insert(0, f"Resultado: {' | '.join(result)}")
        self.update_history()

        if is_jackpot(result):
            self.total_points += 50
            self.credits += 10
            self.update_display()
            generate_particles(WIDTH // 2, HEIGHT // 2)  # Dispara o efeito visual
            self.result_label.config(text="🎉 JACKPOT! 🎉")
            if sound_win:
                sound_win.play()
        else:
            if sound_loss:
                sound_loss.play()

    def update_display(self):
        self.credit_label.config(text=f"Créditos: {self.credits}")
        self.points_label.config(text=f"Pontuação: {self.total_points}")
        self.progress['value'] = self.credits

    def update_history(self):
        self.history_list.delete(0, tk.END)
        for entry in self.history[:10]:
            self.history_list.insert(tk.END, entry)

    def end_game(self):
        messagebox.showinfo("Game Over", "Seus créditos acabaram!")
        if messagebox.askyesno("Reiniciar?", "Deseja jogar novamente?"):
            self.credits = 5
            self.total_points = 0
            self.history.clear()
            self.update_display()
            self.update_history()
            self.result_label.config(text="🃏 | 🃏 | 🃏")
        else:
            self.destroy()

    def update_particles_loop(self):
        update_particles()
        draw_particles()
        self.after(30, self.update_particles_loop)

if __name__ == "__main__":
    app = JackpotApp()
    app.mainloop()
    pygame.quit()
